
import argparse
from pathlib import Path
import numpy as np
import pandas as pd

def seed_everything(seed:int=42):
    np.random.seed(seed)

def generate_users(num_users:int)->pd.DataFrame:
    return pd.DataFrame({
        "user_id":[f"U{i}" for i in range(num_users)],
        "account_age_days":np.random.randint(10,2000,num_users),
        "home_region":np.random.choice(["MUM","DEL","BLR","HYD","CHN","PNQ"],num_users),
        "avg_logins_per_day":np.random.gamma(2.0,1.2,num_users).clip(0.1,20)
    })

def generate_devices(users_df:pd.DataFrame)->pd.DataFrame:
    rows=[]
    for uid in users_df["user_id"].values:
        n=np.random.choice([1,2,3],p=[0.75,0.20,0.05])
        for j in range(n):
            rows.append({
                "device_id":f"D_{uid}_{j}",
                "user_id":uid,
                "device_consistency":np.random.uniform(0.75,1.0) if j==0 else np.random.uniform(0.55,0.9),
                "is_new_device":1 if np.random.rand() < (0.03 if j==0 else 0.25) else 0,
                "device_age_days":np.random.randint(1,1200),
                "os_type":np.random.choice(["android","ios"],p=[0.82,0.18])
            })
    return pd.DataFrame(rows)

def generate_behavior(users_df:pd.DataFrame)->pd.DataFrame:
    return pd.DataFrame({
        "user_id":users_df["user_id"].values,
        "behavior_score":np.random.beta(8,2,len(users_df)).clip(0.1,1.0),
        "usual_login_hour":np.random.choice(range(24),len(users_df)),
        "behavior_volatility":np.random.beta(2,8,len(users_df))
    })

def sigmoid(x):
    return 1.0/(1.0+np.exp(-x))

def generate_events(users_df, devices_df, behavior_df, num_events:int, seed:int=42)->pd.DataFrame:
    rng=np.random.default_rng(seed)
    sampled=devices_df.sample(num_events,replace=True,random_state=seed).reset_index(drop=True)
    events=pd.DataFrame({"event_id":[f"E{i}" for i in range(num_events)],
                         "user_id":sampled["user_id"].values,
                         "device_id":sampled["device_id"].values})
    bmap=behavior_df.set_index("user_id")
    usual=events["user_id"].map(bmap["usual_login_hour"]).fillna(12).astype(int).values
    base_behavior=events["user_id"].map(bmap["behavior_score"]).fillna(0.7).values

    events["timestamp_idx"]=rng.integers(0,60*24*30,size=num_events)
    events["login_hour"]=(usual+rng.choice([-3,-2,-1,0,1,2,3,8,12],size=num_events,p=[.07,.08,.12,.35,.12,.08,.07,.06,.05]))%24
    events["app_risk_tier"]=rng.choice([0,1,2],size=num_events,p=[0.70,0.25,0.05])
    events["sim_changed_recently"]=rng.choice([0,1],size=num_events,p=[0.94,0.06])
    events["geo_distance_from_last_login"]=rng.gamma(2.0,8.0,size=num_events).clip(0,500)
    events["time_since_last_login_min"]=rng.gamma(2.0,180.0,size=num_events).clip(1,10080)
    events["velocity_kmph"]=(events["geo_distance_from_last_login"]/(events["time_since_last_login_min"]/60.0)).clip(0,1200)
    events["num_logins_last_24h"]=rng.poisson(2.5,size=num_events).clip(0,100)
    events["behavior_score"]=np.clip(base_behavior+rng.normal(0,0.12,size=num_events),0,1)

    events=events.merge(devices_df[["user_id","device_id","device_consistency","is_new_device"]],
                        on=["user_id","device_id"],how="left")

    hidden_credential_leak=rng.choice([0,1],size=num_events,p=[0.985,0.015])
    hidden_malware=rng.choice([0,1],size=num_events,p=[0.99,0.01])
    hidden_social=rng.choice([0,1],size=num_events,p=[0.98,0.02])
    logit=(-3.2
           +2.7*events["sim_changed_recently"].values
           +1.7*events["is_new_device"].values
           +2.0*(1-events["device_consistency"].values)
           +1.6*(1-events["behavior_score"].values)
           +1.0*(events["velocity_kmph"].values>500)
           +0.6*(events["num_logins_last_24h"].values>10)
           +0.5*events["app_risk_tier"].values
           +3.0*hidden_credential_leak+3.2*hidden_malware+2.2*hidden_social
           +rng.normal(0,0.6,size=num_events))
    fraud_prob=sigmoid(logit)
    events["is_fraud"]=(rng.random(num_events)<fraud_prob).astype(int)
    return events.sort_values(["user_id","timestamp_idx"]).reset_index(drop=True)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--num-users",type=int,default=100_000)
    parser.add_argument("--num-events",type=int,default=1_000_000)
    parser.add_argument("--out-dir",type=str,default="data/raw")
    parser.add_argument("--seed",type=int,default=42)
    args=parser.parse_args()
    seed_everything(args.seed)
    out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
    users=generate_users(args.num_users)
    devices=generate_devices(users)
    behavior=generate_behavior(users)
    events=generate_events(users,devices,behavior,args.num_events,args.seed)
    users.to_parquet(out/"users.parquet",index=False)
    devices.to_parquet(out/"devices.parquet",index=False)
    behavior.to_parquet(out/"behavior.parquet",index=False)
    events.to_parquet(out/"events.parquet",index=False)
    print(f"users={len(users):,} devices={len(devices):,} events={len(events):,} fraud_rate={events['is_fraud'].mean():.4f}")

if __name__=="__main__":
    main()
