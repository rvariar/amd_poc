
import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd

DEFAULT_FEATURES=["device_consistency","is_new_device","behavior_score","sim_changed_recently","geo_distance_from_last_login","login_hour","time_since_last_login_min","num_logins_last_24h","velocity_kmph","app_risk_tier"]

def build_sequences(events:pd.DataFrame, feature_cols, seq_len:int):
    events=events.sort_values(["user_id","timestamp_idx"]).reset_index(drop=True)
    xs, ys, meta = [], [], []
    for uid,g in events.groupby("user_id",sort=False):
        arr=g[feature_cols].astype("float32").values
        labels=g["is_fraud"].astype("int64").values
        eids=g["event_id"].values
        if len(g)<seq_len: continue
        for i in range(seq_len-1,len(g)):
            xs.append(arr[i-seq_len+1:i+1])
            ys.append(labels[i])
            meta.append((eids[i],uid))
    return np.stack(xs).astype("float32"), np.array(ys).astype("int64"), pd.DataFrame(meta,columns=["event_id","user_id"])

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--events-path",default="data/raw/events.parquet")
    p.add_argument("--out-dir",default="data/processed")
    p.add_argument("--seq-len",type=int,default=30)
    args=p.parse_args()
    out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
    events=pd.read_parquet(args.events_path)
    X,y,meta=build_sequences(events,DEFAULT_FEATURES,args.seq_len)
    np.save(out/"X_sequences.npy",X); np.save(out/"y_sequences.npy",y)
    meta.to_parquet(out/"sequence_meta.parquet",index=False)
    (out/"sequence_config.json").write_text(json.dumps({"seq_len":args.seq_len,"feature_cols":DEFAULT_FEATURES},indent=2))
    print(f"X={X.shape} y={y.shape} fraud_rate={y.mean():.4f}")

if __name__=="__main__":
    main()
