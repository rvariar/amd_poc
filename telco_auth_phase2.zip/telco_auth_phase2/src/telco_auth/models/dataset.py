
import numpy as np
import torch
from torch.utils.data import Dataset

class TelcoSequenceDataset(Dataset):
    def __init__(self, x_path:str, y_path:str):
        self.X=np.load(x_path,mmap_mode="r")
        self.y=np.load(y_path,mmap_mode="r")
    def __len__(self):
        return len(self.y)
    def __getitem__(self,idx):
        return torch.tensor(self.X[idx],dtype=torch.float32), torch.tensor(self.y[idx],dtype=torch.long)
