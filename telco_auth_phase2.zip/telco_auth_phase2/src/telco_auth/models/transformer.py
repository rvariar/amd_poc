
import torch
import torch.nn as nn

class TelcoTransformerRiskModel(nn.Module):
    def __init__(self,num_features:int,d_model:int=128,nhead:int=8,num_layers:int=3,dim_feedforward:int=256,dropout:float=0.10):
        super().__init__()
        self.input_proj=nn.Linear(num_features,d_model)
        self.pos_embedding=nn.Parameter(torch.zeros(1,512,d_model))
        enc=nn.TransformerEncoderLayer(d_model=d_model,nhead=nhead,dim_feedforward=dim_feedforward,dropout=dropout,batch_first=True,activation="gelu")
        self.encoder=nn.TransformerEncoder(enc,num_layers=num_layers)
        self.classifier=nn.Sequential(nn.LayerNorm(d_model),nn.Linear(d_model,64),nn.GELU(),nn.Dropout(dropout),nn.Linear(64,2))
    def forward(self,x):
        seq_len=x.size(1)
        h=self.input_proj(x)+self.pos_embedding[:,:seq_len,:]
        h=self.encoder(h)
        return self.classifier(h[:,-1,:])
