
import numpy as np
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score, recall_score, precision_score, f1_score

def threshold_report(y_true,y_prob,thresholds=None):
    if thresholds is None:
        thresholds=np.arange(0.10,0.91,0.05)
    rows=[]
    for t in thresholds:
        y_pred=(y_prob>=t).astype(int)
        rows.append({"threshold":float(t),"recall":float(recall_score(y_true,y_pred,zero_division=0)),"precision":float(precision_score(y_true,y_pred,zero_division=0)),"f1":float(f1_score(y_true,y_pred,zero_division=0)),"otp_rate":float(y_pred.mean())})
    return rows

def print_eval(y_true,y_prob,threshold=0.30):
    y_pred=(y_prob>=threshold).astype(int)
    print(classification_report(y_true,y_pred))
    cm=confusion_matrix(y_true,y_pred)
    print("Confusion Matrix:\n",cm)
    tn,fp,fn,tp=cm.ravel()
    recall=float(recall_score(y_true,y_pred))
    auc=float(roc_auc_score(y_true,y_prob))
    print(f"False Negatives: {fn}")
    print(f"Recall: {recall:.4f}")
    print(f"ROC-AUC: {auc:.4f}")
    return {"tn":int(tn),"fp":int(fp),"fn":int(fn),"tp":int(tp),"recall":recall,"roc_auc":auc}
