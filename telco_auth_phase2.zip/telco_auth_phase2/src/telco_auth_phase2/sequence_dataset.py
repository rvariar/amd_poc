from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from telco_auth_phase2.io_utils import read_table
from torch.utils.data import Dataset

FEATURE_COLUMNS = [
    "device_consistency",
    "is_new_device",
    "behavior_score",
    "sim_changed_recently",
    "geo_distance_from_last_login",
    "login_hour_sin",
    "login_hour_cos",
    "roaming",
    "failed_login_count_1h",
    "num_logins_last_24h",
    "velocity_km_per_hr",
    "network_5g",
    "network_4g",
    "network_wifi",
]


def load_joined(raw_dir: str | Path) -> pd.DataFrame:
    raw = Path(raw_dir)
    events = read_table(raw / "events")
    labels = read_table(raw / "labels")
    devices = read_table(raw / "devices")
    behavior = read_table(raw / "behavior")

    df = events.merge(labels[["event_id", "is_fraud"]], on="event_id", how="inner")
    df = df.merge(devices[["user_id", "device_id", "device_consistency", "is_new_device"]], on=["user_id", "device_id"], how="left")
    df = df.merge(behavior[["user_id", "behavior_score"]], on="user_id", how="left")
    df = df.sort_values(["user_id", "timestamp"]).reset_index(drop=True)
    return df


def add_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["login_hour_sin"] = np.sin(2 * np.pi * df["login_hour"] / 24.0)
    df["login_hour_cos"] = np.cos(2 * np.pi * df["login_hour"] / 24.0)
    df["network_5g"] = (df["network_type"] == "5G").astype(float)
    df["network_4g"] = (df["network_type"] == "4G").astype(float)
    df["network_wifi"] = (df["network_type"] == "WiFi").astype(float)

    for col in ["geo_distance_from_last_login", "failed_login_count_1h", "num_logins_last_24h", "velocity_km_per_hr"]:
        q99 = df[col].quantile(0.99)
        if q99 and q99 > 0:
            df[col] = (df[col].clip(0, q99) / q99).astype(float)

    df[FEATURE_COLUMNS] = df[FEATURE_COLUMNS].fillna(0.0).astype("float32")
    df["is_fraud"] = df["is_fraud"].astype("float32")
    return df


def build_sequences(df: pd.DataFrame, seq_len: int) -> tuple[np.ndarray, np.ndarray]:
    sequences: list[np.ndarray] = []
    labels: list[float] = []

    for _, g in df.groupby("user_id", sort=False):
        arr = g[FEATURE_COLUMNS].values.astype("float32")
        y = g["is_fraud"].values.astype("float32")
        if len(g) < seq_len:
            continue
        for end_idx in range(seq_len - 1, len(g)):
            start_idx = end_idx - seq_len + 1
            sequences.append(arr[start_idx:end_idx + 1])
            labels.append(y[end_idx])

    return np.stack(sequences), np.asarray(labels, dtype="float32")


def save_sequences(raw_dir: str | Path, out_dir: str | Path, seq_len: int) -> None:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    df = add_features(load_joined(raw_dir))
    X, y = build_sequences(df, seq_len)
    np.save(out / "X_seq.npy", X)
    np.save(out / "y_seq.npy", y)
    pd.Series(FEATURE_COLUMNS).to_csv(out / "feature_columns.csv", index=False, header=False)
    print(f"Saved sequences: X={X.shape}, y={y.shape}, fraud_rate={y.mean():.4f}")


class TelcoSequenceDataset(Dataset):
    def __init__(self, X: np.ndarray, y: np.ndarray):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.float32)

    def __len__(self) -> int:
        return len(self.y)

    def __getitem__(self, idx: int):
        return self.X[idx], self.y[idx]


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-dir", type=str, default="data/raw")
    parser.add_argument("--out-dir", type=str, default="data/processed")
    parser.add_argument("--seq-len", type=int, default=30)
    args = parser.parse_args()
    save_sequences(args.raw_dir, args.out_dir, args.seq_len)
