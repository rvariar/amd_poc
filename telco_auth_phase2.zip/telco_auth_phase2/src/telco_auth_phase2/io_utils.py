from __future__ import annotations
from pathlib import Path
import pandas as pd


def save_table(df: pd.DataFrame, path_without_ext: str | Path) -> None:
    path = Path(path_without_ext)
    try:
        df.to_parquet(path.with_suffix('.parquet'), index=False)
    except Exception:
        df.to_csv(path.with_suffix('.csv'), index=False)


def read_table(path_without_ext: str | Path) -> pd.DataFrame:
    path = Path(path_without_ext)
    pq = path.with_suffix('.parquet')
    csv = path.with_suffix('.csv')
    if pq.exists():
        return pd.read_parquet(pq)
    if csv.exists():
        return pd.read_csv(csv)
    raise FileNotFoundError(f'Could not find {pq} or {csv}')
