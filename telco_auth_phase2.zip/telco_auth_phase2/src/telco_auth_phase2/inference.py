from __future__ import annotations

from pathlib import Path
import json
import numpy as np
import torch

from telco_auth_phase2.model import TelcoAuthTransformer
from telco_auth_phase2.sequence_dataset import FEATURE_COLUMNS


def load_model(model_path: str | Path, device: str | None = None):
    device_obj = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
    ckpt = torch.load(model_path, map_location=device_obj)
    cfg = ckpt["config"]
    model = TelcoAuthTransformer(input_dim=ckpt["input_dim"], **cfg).to(device_obj)
    model.load_state_dict(ckpt["model_state_dict"])
    model.eval()
    return model, device_obj


def score_sequence(model, device, sequence: np.ndarray) -> float:
    """sequence shape: [seq_len, num_features]."""
    with torch.no_grad():
        x = torch.tensor(sequence, dtype=torch.float32).unsqueeze(0).to(device)
        prob = torch.sigmoid(model(x)).item()
    return float(prob)


def decision_from_score(prob: float) -> dict:
    if prob < 0.25:
        decision = "NO_OTP"
        risk_level = "low"
    elif prob < 0.60:
        decision = "STEP_UP_AUTH"
        risk_level = "medium"
    else:
        decision = "OTP_REQUIRED"
        risk_level = "high"
    return {"risk_score": round(prob, 4), "risk_level": risk_level, "decision": decision}


def build_llm_prompt(score_result: dict, latest_features: dict) -> str:
    return f"""
You are a Telco Security LLM.
Explain the authentication decision in JSON.

Risk result: {json.dumps(score_result)}
Latest event features: {json.dumps(latest_features)}

Return JSON only:
{{
  "decision": "...",
  "reason": "...",
  "audit_notes": ["...", "..."]
}}
"""
