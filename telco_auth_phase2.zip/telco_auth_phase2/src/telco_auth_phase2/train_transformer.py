from __future__ import annotations

import argparse
from pathlib import Path
import json
import numpy as np
import torch
from torch.utils.data import DataLoader, random_split
from tqdm import tqdm
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score, recall_score, precision_score

from telco_auth_phase2.sequence_dataset import TelcoSequenceDataset
from telco_auth_phase2.model import TelcoAuthTransformer


def get_device() -> torch.device:
    # On ROCm, torch.cuda.is_available() is still the common check.
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def evaluate(model, loader, device, threshold: float = 0.30) -> dict:
    model.eval()
    probs, labels = [], []
    with torch.no_grad():
        for X, y in loader:
            X = X.to(device)
            logits = model(X)
            probs.extend(torch.sigmoid(logits).detach().cpu().numpy().tolist())
            labels.extend(y.numpy().tolist())
    probs = np.asarray(probs)
    labels = np.asarray(labels).astype(int)
    preds = (probs > threshold).astype(int)
    return {
        "threshold": threshold,
        "recall": float(recall_score(labels, preds, zero_division=0)),
        "precision": float(precision_score(labels, preds, zero_division=0)),
        "roc_auc": float(roc_auc_score(labels, probs)) if len(set(labels)) > 1 else None,
        "confusion_matrix": confusion_matrix(labels, preds).tolist(),
        "classification_report": classification_report(labels, preds, zero_division=0),
    }


def threshold_sweep(model, loader, device) -> list[dict]:
    results = []
    for t in np.arange(0.10, 0.91, 0.05):
        m = evaluate(model, loader, device, threshold=float(round(t, 2)))
        results.append({"threshold": m["threshold"], "recall": m["recall"], "precision": m["precision"], "roc_auc": m["roc_auc"]})
    return results


def train(processed_dir: str | Path, model_dir: str | Path, reports_dir: str | Path, epochs: int, batch_size: int, lr: float, hidden_dim: int, num_layers: int, num_heads: int, dropout: float, threshold: float, seed: int):
    torch.manual_seed(seed)
    np.random.seed(seed)
    processed = Path(processed_dir)
    model_out = Path(model_dir)
    reports = Path(reports_dir)
    model_out.mkdir(parents=True, exist_ok=True)
    reports.mkdir(parents=True, exist_ok=True)

    X = np.load(processed / "X_seq.npy", mmap_mode="r")
    y = np.load(processed / "y_seq.npy", mmap_mode="r")
    dataset = TelcoSequenceDataset(np.asarray(X), np.asarray(y))

    n_total = len(dataset)
    n_train = int(0.70 * n_total)
    n_val = int(0.15 * n_total)
    n_test = n_total - n_train - n_val
    train_ds, val_ds, test_ds = random_split(dataset, [n_train, n_val, n_test], generator=torch.Generator().manual_seed(seed))

    device = get_device()
    pin = device.type == "cuda"
    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, num_workers=0, pin_memory=pin)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False, num_workers=0, pin_memory=pin)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False, num_workers=0, pin_memory=pin)

    input_dim = X.shape[-1]
    model = TelcoAuthTransformer(input_dim=input_dim, hidden_dim=hidden_dim, num_heads=num_heads, num_layers=num_layers, dropout=dropout).to(device)

    fraud_rate = float(np.asarray(y).mean())
    pos_weight = torch.tensor([(1.0 - fraud_rate) / max(fraud_rate, 1e-6)], dtype=torch.float32).to(device)
    criterion = torch.nn.BCEWithLogitsLoss(pos_weight=pos_weight)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)

    history = []
    best_recall = -1.0
    best_path = model_out / "telco_auth_transformer.pt"

    print(f"Device: {device}; input_dim={input_dim}; samples={n_total:,}; fraud_rate={fraud_rate:.4f}; pos_weight={pos_weight.item():.2f}")

    for epoch in range(1, epochs + 1):
        model.train()
        losses = []
        for Xb, yb in tqdm(train_loader, desc=f"epoch {epoch}/{epochs}"):
            Xb = Xb.to(device, non_blocking=True)
            yb = yb.to(device, non_blocking=True)
            optimizer.zero_grad()
            logits = model(Xb)
            loss = criterion(logits, yb)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            losses.append(float(loss.detach().cpu()))

        val_metrics = evaluate(model, val_loader, device, threshold=threshold)
        row = {"epoch": epoch, "train_loss": float(np.mean(losses)), **val_metrics}
        history.append(row)
        print(f"epoch={epoch} loss={row['train_loss']:.4f} val_recall={row['recall']:.4f} val_precision={row['precision']:.4f} val_auc={row['roc_auc']}")

        if row["recall"] > best_recall:
            best_recall = row["recall"]
            torch.save({"model_state_dict": model.state_dict(), "input_dim": input_dim, "config": {"hidden_dim": hidden_dim, "num_heads": num_heads, "num_layers": num_layers, "dropout": dropout}}, best_path)

    checkpoint = torch.load(best_path, map_location=device)
    model.load_state_dict(checkpoint["model_state_dict"])
    test_metrics = evaluate(model, test_loader, device, threshold=threshold)
    sweep = threshold_sweep(model, test_loader, device)

    (reports / "training_history.json").write_text(json.dumps(history, indent=2))
    (reports / "test_metrics.json").write_text(json.dumps(test_metrics, indent=2))
    (reports / "threshold_sweep.json").write_text(json.dumps(sweep, indent=2))

    print("\n=== TEST METRICS ===")
    print(test_metrics["classification_report"])
    print("Confusion Matrix:", test_metrics["confusion_matrix"])
    print(f"ROC-AUC={test_metrics['roc_auc']}; Recall={test_metrics['recall']}; Precision={test_metrics['precision']}")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--processed-dir", default="data/processed")
    p.add_argument("--model-dir", default="models")
    p.add_argument("--reports-dir", default="reports")
    p.add_argument("--epochs", type=int, default=5)
    p.add_argument("--batch-size", type=int, default=512)
    p.add_argument("--lr", type=float, default=5e-4)
    p.add_argument("--hidden-dim", type=int, default=128)
    p.add_argument("--num-layers", type=int, default=2)
    p.add_argument("--num-heads", type=int, default=4)
    p.add_argument("--dropout", type=float, default=0.15)
    p.add_argument("--threshold", type=float, default=0.30)
    p.add_argument("--seed", type=int, default=42)
    args = p.parse_args()
    train(args.processed_dir, args.model_dir, args.reports_dir, args.epochs, args.batch_size, args.lr, args.hidden_dim, args.num_layers, args.num_heads, args.dropout, args.threshold, args.seed)
