from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from telco_auth_phase2.io_utils import save_table


def set_seed(seed: int) -> np.random.Generator:
    return np.random.default_rng(seed)


def generate_users(num_users: int, rng: np.random.Generator) -> pd.DataFrame:
    return pd.DataFrame({
        "user_id": [f"U{i}" for i in range(num_users)],
        "account_age_days": rng.integers(10, 2500, size=num_users),
        "avg_daily_logins": rng.uniform(1, 8, size=num_users),
        "home_cell_cluster": rng.integers(1, 5000, size=num_users),
        "risk_profile": rng.choice(["low", "medium", "high"], size=num_users, p=[0.70, 0.25, 0.05]),
    })


def generate_devices(num_devices: int, users_df: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    user_ids = rng.choice(users_df["user_id"].values, size=num_devices, replace=True)
    is_new = rng.choice([0, 1], size=num_devices, p=[0.85, 0.15])
    return pd.DataFrame({
        "device_id": [f"D{i}" for i in range(num_devices)],
        "user_id": user_ids,
        "device_consistency": rng.uniform(0.55, 1.0, size=num_devices),
        "is_new_device": is_new,
        "device_age_days": np.where(is_new == 1, rng.integers(0, 14, size=num_devices), rng.integers(15, 1500, size=num_devices)),
        "os_type": rng.choice(["android", "ios"], size=num_devices, p=[0.82, 0.18]),
    })


def generate_behavior(users_df: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    n = len(users_df)
    return pd.DataFrame({
        "user_id": users_df["user_id"].values,
        "behavior_score": rng.uniform(0.50, 1.0, size=n),
        "login_time_variance": rng.uniform(0.0, 6.0, size=n),
        "device_switch_frequency": rng.uniform(0.0, 0.7, size=n),
    })


def generate_events(num_events: int, devices_df: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    # Valid device-user pairs only.
    sampled = devices_df.sample(num_events, replace=True, random_state=int(rng.integers(0, 1_000_000))).reset_index(drop=True)
    timestamps = pd.Timestamp("2026-01-01") + pd.to_timedelta(rng.integers(0, 90 * 24 * 3600, size=num_events), unit="s")

    events = pd.DataFrame({
        "event_id": [f"E{i}" for i in range(num_events)],
        "user_id": sampled["user_id"].values,
        "device_id": sampled["device_id"].values,
        "timestamp": timestamps,
        "login_hour": timestamps.hour,
        "sim_changed_recently": rng.choice([0, 1], size=num_events, p=[0.90, 0.10]),
        "geo_distance_from_last_login": rng.exponential(scale=12.0, size=num_events).clip(0, 500),
        "network_type": rng.choice(["5G", "4G", "WiFi"], size=num_events, p=[0.55, 0.25, 0.20]),
        "roaming": rng.choice([0, 1], size=num_events, p=[0.96, 0.04]),
        "failed_login_count_1h": rng.poisson(0.2, size=num_events),
        "num_logins_last_24h": rng.poisson(3.0, size=num_events),
        "app_category": rng.choice(["food", "grocery", "ott", "ecommerce", "wallet"], size=num_events, p=[0.28, 0.18, 0.20, 0.24, 0.10]),
    })
    events["velocity_km_per_hr"] = (events["geo_distance_from_last_login"] / rng.uniform(0.1, 24.0, size=num_events)).clip(0, 1200)
    return events.sort_values(["user_id", "timestamp"]).reset_index(drop=True)


def generate_labels(events_df: pd.DataFrame, devices_df: pd.DataFrame, behavior_df: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    df = events_df.merge(devices_df[["user_id", "device_id", "device_consistency", "is_new_device"]], on=["user_id", "device_id"], how="left")
    df = df.merge(behavior_df[["user_id", "behavior_score", "device_switch_frequency"]], on="user_id", how="left")

    hidden_compromise = rng.binomial(1, 0.035, size=len(df))
    social_engineering = rng.binomial(1, 0.025, size=len(df))
    random_noise = rng.normal(0.0, 0.12, size=len(df))

    # Probabilistic risk, intentionally not a perfectly deterministic rule.
    risk = (
        0.85 * df["sim_changed_recently"].astype(float)
        + 0.55 * df["is_new_device"].astype(float)
        + 0.40 * (1.0 - df["device_consistency"].astype(float))
        + 0.35 * (1.0 - df["behavior_score"].astype(float))
        + 0.25 * (df["geo_distance_from_last_login"] > 80).astype(float)
        + 0.25 * (df["velocity_km_per_hr"] > 250).astype(float)
        + 0.20 * (df["failed_login_count_1h"] >= 3).astype(float)
        + 0.55 * hidden_compromise
        + 0.40 * social_engineering
        + random_noise
    )
    probability = 1 / (1 + np.exp(-(risk - 1.15)))
    labels = rng.binomial(1, probability)

    return pd.DataFrame({
        "event_id": events_df["event_id"].values,
        "is_fraud": labels,
        "fraud_probability_simulated": probability,
    })


def generate_all(num_users: int, num_devices: int, num_events: int, seed: int, out_dir: str | Path) -> None:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    rng = set_seed(seed)
    users = generate_users(num_users, rng)
    devices = generate_devices(num_devices, users, rng)
    behavior = generate_behavior(users, rng)
    events = generate_events(num_events, devices, rng)
    labels = generate_labels(events, devices, behavior, rng)

    save_table(users, out / "users")
    save_table(devices, out / "devices")
    save_table(behavior, out / "behavior")
    save_table(events, out / "events")
    save_table(labels, out / "labels")

    print(f"Generated data under {out.resolve()}")
    print(f"Users={len(users):,}, Devices={len(devices):,}, Events={len(events):,}, Fraud rate={labels['is_fraud'].mean():.4f}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--num-users", type=int, default=100_000)
    parser.add_argument("--num-devices", type=int, default=150_000)
    parser.add_argument("--num-events", type=int, default=1_000_000)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--out-dir", type=str, default="data/raw")
    args = parser.parse_args()
    generate_all(args.num_users, args.num_devices, args.num_events, args.seed, args.out_dir)
