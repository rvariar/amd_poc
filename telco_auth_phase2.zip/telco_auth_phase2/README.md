# Telco Auth Phase 2 — ROCm/GPU Sequence Risk Model

Phase 2 upgrades the Build 1 RandomForest baseline into a GPU-suitable sequence model.

## Goal
Train a Transformer model on user login sequences to predict authentication fraud risk and support OTP / step-up / no-OTP decisions.

## Architecture

```text
Synthetic Telco Identity Data Generator
        ↓
Large-scale Auth Events + User Sequences
        ↓
PyTorch Transformer Risk Model on ROCm/CUDA/CPU
        ↓
Recall-Optimized Threshold Engine
        ↓
Rule Guardrails
        ↓
Qwen 30B/70B via vLLM for Explanation + Audit Trail
```

## Directory Structure

```text
telco_auth_phase2/
├── configs/phase2_config.yaml
├── data/raw/
├── data/processed/
├── models/
├── reports/
├── scripts/
└── src/telco_auth_phase2/
```

## Quick Run

For a small local smoke test:

```bash
python scripts/run_phase2_pipeline.py --num-users 5000 --num-devices 7000 --num-events 100000 --epochs 2
```

For a larger GPU run:

```bash
python scripts/run_phase2_pipeline.py --num-users 1000000 --num-devices 1500000 --num-events 50000000 --epochs 10 --batch-size 2048
```

## ROCm Note
PyTorch on AMD ROCm usually exposes the GPU through `torch.cuda`. So the code uses:

```python
device = "cuda" if torch.cuda.is_available() else "cpu"
```

On ROCm, this still maps to the AMD GPU backend.
