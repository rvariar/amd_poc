#!/usr/bin/env python
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"


def run(cmd):
    print("\n$", " ".join(str(c) for c in cmd))
    subprocess.check_call([str(c) for c in cmd], cwd=ROOT)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--num-users", type=int, default=5000)
    p.add_argument("--num-devices", type=int, default=7000)
    p.add_argument("--num-events", type=int, default=100000)
    p.add_argument("--seq-len", type=int, default=30)
    p.add_argument("--epochs", type=int, default=2)
    p.add_argument("--batch-size", type=int, default=512)
    args = p.parse_args()

    env = dict(**__import__("os").environ)
    env["PYTHONPATH"] = str(SRC)

    cmds = [
        [sys.executable, "-m", "telco_auth_phase2.data_generator", "--num-users", args.num_users, "--num-devices", args.num_devices, "--num-events", args.num_events, "--out-dir", "data/raw"],
        [sys.executable, "-m", "telco_auth_phase2.sequence_dataset", "--raw-dir", "data/raw", "--out-dir", "data/processed", "--seq-len", args.seq_len],
        [sys.executable, "-m", "telco_auth_phase2.train_transformer", "--processed-dir", "data/processed", "--model-dir", "models", "--reports-dir", "reports", "--epochs", args.epochs, "--batch-size", args.batch_size],
    ]
    for cmd in cmds:
        print("\n$", " ".join(str(c) for c in cmd))
        subprocess.check_call([str(c) for c in cmd], cwd=ROOT, env=env)
