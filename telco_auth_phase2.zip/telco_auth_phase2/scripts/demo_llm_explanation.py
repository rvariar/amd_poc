from __future__ import annotations

import os
import json
from pydantic_ai import Agent
from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.providers.openai import OpenAIProvider

sample_score = {"risk_score": 0.72, "risk_level": "high", "decision": "OTP_REQUIRED"}
sample_features = {"sim_changed_recently": 1, "is_new_device": 1, "behavior_score": 0.41, "device_consistency": 0.58}

provider = OpenAIProvider(
    base_url=os.environ.get("BASE_URL", "http://localhost:8000/v1"),
    api_key=os.environ.get("OPENAI_API_KEY", "abc-123"),
)
llm = OpenAIChatModel(model_name=os.environ.get("MODEL_NAME", "Qwen3-30B-A3B"), provider=provider)

agent = Agent(
    model=llm,
    system_prompt="""
You are a Telco Security LLM. Return JSON only.
Map risk into NO_OTP, STEP_UP_AUTH, or OTP_REQUIRED. Explain using telco security terms.
""",
)

async def main():
    prompt = f"Risk result: {json.dumps(sample_score)}\nFeatures: {json.dumps(sample_features)}"
    result = await agent.run(prompt)
    print(result.output)

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
