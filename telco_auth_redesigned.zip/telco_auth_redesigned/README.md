# Telco Adaptive Authentication: Build 2 + Build 3 Scaffold

## Build 2
ROCm/GPU-oriented sequence Transformer risk model.

Goal: predict the risk of the **next mobile authentication event** from the user's last N authentication events.

This justifies GPU usage because it trains on large user-event sequences rather than small tabular rows.

## Build 3
Fine-tuned Telco Security LLM dataset scaffold.

Goal: create instruction-tuning data from model outputs so Qwen can explain OTP / step-up / no-OTP decisions like a telco security analyst.

## Quick run

```bash
cd telco_auth_redesigned
python -m venv myenv
source myenv/bin/activate
pip install -r requirements.txt
PYTHONPATH=src python scripts/run_build2_pipeline.py --num-users 5000 --events-per-user 40 --epochs 2
PYTHONPATH=src python scripts/create_build3_finetune_data.py --num-samples 10000
```

For ROCm, install a ROCm-enabled PyTorch build matching your environment before running training.
