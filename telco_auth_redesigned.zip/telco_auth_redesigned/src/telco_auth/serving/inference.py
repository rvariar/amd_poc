from __future__ import annotations

from pathlib import Path
import pandas as pd
import torch

from telco_auth.models.transformer_risk_model import TransformerRiskModel
from telco_auth.schemas.event_schema import FEATURE_COLUMNS
from telco_auth.utils.device import get_device


class SequenceRiskScorer:
    def __init__(self, checkpoint: str = 'artifacts/checkpoints/transformer_risk_model.pt'):
        self.device = get_device()
        ckpt = torch.load(checkpoint, map_location=self.device)
        self.seq_len = ckpt['seq_len']
        self.feature_columns = ckpt.get('feature_columns', FEATURE_COLUMNS)
        self.model = TransformerRiskModel(feature_dim=len(self.feature_columns)).to(self.device)
        self.model.load_state_dict(ckpt['model_state_dict'])
        self.model.eval()

    def score_user_history(self, events: pd.DataFrame) -> dict:
        events = events.sort_values('event_index').tail(self.seq_len)
        if len(events) < self.seq_len:
            raise ValueError(f'Need at least {self.seq_len} events for sequence scoring')
        x = torch.tensor(events[self.feature_columns].astype('float32').to_numpy(), dtype=torch.float32).unsqueeze(0).to(self.device)
        with torch.no_grad():
            prob = torch.sigmoid(self.model(x)).item()
        return {
            'risk_score': round(prob, 4),
            'risk_level': 'high' if prob > 0.70 else 'medium' if prob > 0.30 else 'low'
        }
