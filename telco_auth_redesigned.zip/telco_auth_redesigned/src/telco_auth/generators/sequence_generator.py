from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd

from telco_auth.schemas.event_schema import EVENT_COLUMNS
from telco_auth.utils.seed import set_seed

APP_TYPES = {
    'food_delivery': 0,
    'grocery': 1,
    'ott': 2,
    'ecommerce': 3,
    'banking': 4,
}


def sigmoid(x: np.ndarray) -> np.ndarray:
    return 1 / (1 + np.exp(-x))


def generate_auth_events(
    num_users: int = 10000,
    events_per_user: int = 50,
    seed: int = 42,
) -> pd.DataFrame:
    """Generate user authentication event sequences.

    Each user has a sequence of auth events. Labels are generated from visible
    signals plus hidden per-user risk to avoid perfect leakage.
    """
    set_seed(seed)
    rows = []

    user_hidden_risk = np.random.beta(2, 12, size=num_users)
    preferred_hour = np.random.randint(6, 24, size=num_users)
    base_behavior = np.random.uniform(0.72, 0.98, size=num_users)

    for u in range(num_users):
        user_id = f'U{u}'
        sim_age = np.random.randint(20, 700)
        device_age = np.random.randint(10, 900)
        last_location = np.random.uniform(0, 50)

        for i in range(events_per_user):
            app_type = np.random.choice(list(APP_TYPES.values()), p=[0.25, 0.18, 0.18, 0.24, 0.15])
            hour = int(np.clip(np.random.normal(preferred_hour[u], 3), 0, 23))
            hour_sin = np.sin(2 * np.pi * hour / 24)
            hour_cos = np.cos(2 * np.pi * hour / 24)

            # More rare but meaningful events.
            sim_changed = np.random.rand() < (0.006 + 0.04 * user_hidden_risk[u])
            imei_changed = np.random.rand() < (0.01 + 0.05 * user_hidden_risk[u])
            is_new_device = np.random.rand() < (0.02 + 0.06 * user_hidden_risk[u])

            if sim_changed:
                sim_age = 0
            else:
                sim_age += 1

            if is_new_device or imei_changed:
                device_age = 0
            else:
                device_age += 1

            location_jump = abs(np.random.normal(3, 8))
            if np.random.rand() < 0.015 + 0.06 * user_hidden_risk[u]:
                location_jump += np.random.uniform(50, 800)
            last_location += np.random.normal(0, 0.5)

            network_5g = int(np.random.rand() < 0.65)
            roaming = int(np.random.rand() < (0.02 + 0.04 * user_hidden_risk[u]))
            behavior_score = float(np.clip(base_behavior[u] - np.random.beta(1.5, 10) - 0.25 * is_new_device, 0.05, 1.0))
            device_consistency = float(np.clip(0.95 - 0.35 * is_new_device - 0.25 * imei_changed + np.random.normal(0, 0.05), 0.05, 1.0))

            # Policy-like historical OTP usage: visible but not equal to label.
            otp_used = int(sim_changed or is_new_device or app_type == APP_TYPES['banking'] or np.random.rand() < 0.08)

            risk_logit = (
                -3.4
                + 2.6 * sim_changed
                + 1.7 * imei_changed
                + 1.2 * is_new_device
                + 1.1 * (behavior_score < 0.55)
                + 1.0 * (location_jump > 100)
                + 0.8 * roaming
                + 0.5 * (app_type == APP_TYPES['banking'])
                + 3.2 * user_hidden_risk[u]
                + np.random.normal(0, 0.8)
            )
            fraud_prob = sigmoid(np.array([risk_logit]))[0]
            is_fraud = int(np.random.rand() < fraud_prob)

            rows.append([
                user_id,
                i,
                i * 60 + np.random.randint(0, 60),
                app_type,
                device_consistency,
                int(is_new_device),
                int(sim_changed),
                int(imei_changed),
                behavior_score,
                float(location_jump),
                float(hour_sin),
                float(hour_cos),
                int(network_5g),
                int(roaming),
                int(otp_used),
                int(is_fraud),
            ])

    return pd.DataFrame(rows, columns=EVENT_COLUMNS)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--num-users', type=int, default=10000)
    parser.add_argument('--events-per-user', type=int, default=50)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--out', type=str, default='data/raw/auth_events.parquet')
    args = parser.parse_args()

    df = generate_auth_events(args.num_users, args.events_per_user, args.seed)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.suffix == '.parquet':
        df.to_parquet(out, index=False)
    else:
        df.to_csv(out, index=False)
    print(f'Wrote {len(df):,} events to {out}')
    print(df['is_fraud'].value_counts(normalize=True).rename('fraud_rate'))


if __name__ == '__main__':
    main()
