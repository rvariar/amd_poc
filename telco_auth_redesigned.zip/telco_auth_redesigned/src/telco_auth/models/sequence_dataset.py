from __future__ import annotations

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset

from telco_auth.schemas.event_schema import FEATURE_COLUMNS


class AuthSequenceDataset(Dataset):
    """Creates sliding windows: last seq_len events -> next event fraud label."""

    def __init__(self, df: pd.DataFrame, seq_len: int = 30):
        self.seq_len = seq_len
        self.feature_cols = FEATURE_COLUMNS
        self.samples: list[tuple[np.ndarray, int]] = []

        df = df.sort_values(['user_id', 'event_index'])
        for _, g in df.groupby('user_id', sort=False):
            if len(g) <= seq_len:
                continue
            x = g[self.feature_cols].astype('float32').to_numpy()
            y = g['is_fraud'].astype('float32').to_numpy()
            for end in range(seq_len, len(g)):
                self.samples.append((x[end - seq_len:end], int(y[end])))

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int):
        x, y = self.samples[idx]
        return torch.tensor(x, dtype=torch.float32), torch.tensor(y, dtype=torch.float32)
