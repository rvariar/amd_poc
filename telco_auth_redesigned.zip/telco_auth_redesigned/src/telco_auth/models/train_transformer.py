from __future__ import annotations

import argparse
from pathlib import Path
import json
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader, random_split
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score, recall_score, precision_score

from telco_auth.models.sequence_dataset import AuthSequenceDataset
from telco_auth.models.transformer_risk_model import TransformerRiskModel
from telco_auth.schemas.event_schema import FEATURE_COLUMNS
from telco_auth.utils.device import get_device, device_report
from telco_auth.utils.seed import set_seed


def load_events(path: str) -> pd.DataFrame:
    p = Path(path)
    return pd.read_parquet(p) if p.suffix == '.parquet' else pd.read_csv(p)


def evaluate(model, loader, device, threshold: float) -> dict:
    model.eval()
    probs, labels = [], []
    with torch.no_grad():
        for x, y in loader:
            x = x.to(device)
            logits = model(x)
            p = torch.sigmoid(logits).detach().cpu().numpy()
            probs.extend(p.tolist())
            labels.extend(y.numpy().tolist())
    probs = np.array(probs)
    labels = np.array(labels).astype(int)
    preds = (probs >= threshold).astype(int)
    return {
        'roc_auc': float(roc_auc_score(labels, probs)) if len(np.unique(labels)) > 1 else 0.0,
        'recall': float(recall_score(labels, preds, zero_division=0)),
        'precision': float(precision_score(labels, preds, zero_division=0)),
        'confusion_matrix': confusion_matrix(labels, preds).tolist(),
        'classification_report': classification_report(labels, preds, zero_division=0),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--events', default='data/raw/auth_events.parquet')
    parser.add_argument('--seq-len', type=int, default=30)
    parser.add_argument('--epochs', type=int, default=3)
    parser.add_argument('--batch-size', type=int, default=512)
    parser.add_argument('--lr', type=float, default=3e-4)
    parser.add_argument('--threshold', type=float, default=0.30)
    parser.add_argument('--out-dir', default='artifacts/checkpoints')
    parser.add_argument('--seed', type=int, default=42)
    args = parser.parse_args()

    set_seed(args.seed)
    device = get_device()
    print(device_report())

    df = load_events(args.events)
    dataset = AuthSequenceDataset(df, seq_len=args.seq_len)
    print(f'Sequence samples: {len(dataset):,} | feature_dim={len(FEATURE_COLUMNS)}')

    train_size = int(0.8 * len(dataset))
    val_size = len(dataset) - train_size
    train_ds, val_ds = random_split(dataset, [train_size, val_size], generator=torch.Generator().manual_seed(args.seed))

    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, num_workers=2, pin_memory=torch.cuda.is_available())
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False, num_workers=2, pin_memory=torch.cuda.is_available())

    model = TransformerRiskModel(feature_dim=len(FEATURE_COLUMNS)).to(device)

    # Fraud is rare. pos_weight increases penalty for missed fraud examples.
    labels = np.array([dataset[i][1].item() for i in range(len(dataset))])
    pos = max(labels.sum(), 1)
    neg = max(len(labels) - pos, 1)
    pos_weight = torch.tensor([neg / pos], dtype=torch.float32, device=device)
    loss_fn = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=0.01)

    history = []
    for epoch in range(1, args.epochs + 1):
        model.train()
        total_loss = 0.0
        for x, y in train_loader:
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad(set_to_none=True)
            logits = model(x)
            loss = loss_fn(logits, y)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * x.size(0)

        train_loss = total_loss / len(train_ds)
        metrics = evaluate(model, val_loader, device, args.threshold)
        print(f"epoch={epoch} loss={train_loss:.4f} recall={metrics['recall']:.4f} precision={metrics['precision']:.4f} auc={metrics['roc_auc']:.4f}")
        history.append({'epoch': epoch, 'loss': train_loss, **{k: v for k, v in metrics.items() if k != 'classification_report'}})

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    torch.save({'model_state_dict': model.state_dict(), 'feature_columns': FEATURE_COLUMNS, 'seq_len': args.seq_len}, out_dir / 'transformer_risk_model.pt')
    with open(out_dir / 'metrics.json', 'w') as f:
        json.dump({'history': history, 'final_report': metrics['classification_report']}, f, indent=2)
    print(metrics['classification_report'])
    print(f'Saved model and metrics to {out_dir}')


if __name__ == '__main__':
    main()
