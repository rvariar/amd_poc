from __future__ import annotations

import torch
from torch import nn


class TransformerRiskModel(nn.Module):
    def __init__(self, feature_dim: int, model_dim: int = 128, num_heads: int = 8, num_layers: int = 4, dropout: float = 0.15):
        super().__init__()
        self.input_proj = nn.Linear(feature_dim, model_dim)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=model_dim,
            nhead=num_heads,
            dim_feedforward=model_dim * 4,
            dropout=dropout,
            activation='gelu',
            batch_first=True,
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.norm = nn.LayerNorm(model_dim)
        self.head = nn.Sequential(
            nn.Linear(model_dim, model_dim // 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(model_dim // 2, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.input_proj(x)
        h = self.encoder(h)
        h = self.norm(h[:, -1, :])
        return self.head(h).squeeze(-1)
