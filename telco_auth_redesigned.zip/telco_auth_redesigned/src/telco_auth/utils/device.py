import torch


def get_device() -> torch.device:
    # On AMD ROCm, torch reports HIP GPUs via the cuda API surface.
    return torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def device_report() -> str:
    if not torch.cuda.is_available():
        return 'CPU only: torch.cuda.is_available() is False'
    return f"GPU available: {torch.cuda.get_device_name(0)} | device_count={torch.cuda.device_count()}"
