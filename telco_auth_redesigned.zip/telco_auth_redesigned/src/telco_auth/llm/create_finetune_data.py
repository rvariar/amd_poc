from __future__ import annotations

import argparse
import json
from pathlib import Path
import random
import numpy as np

DECISION_MAP = {
    'low': 'NO_OTP',
    'medium': 'STEP_UP_AUTH',
    'high': 'OTP_REQUIRED',
}


def explain(signals: dict, risk_score: float, decision: str) -> str:
    reasons = []
    if signals['sim_changed_recently']:
        reasons.append('recent SIM change indicates possible SIM-swap risk')
    if signals['imei_changed']:
        reasons.append('IMEI change suggests the SIM may be used in a different handset')
    if signals['is_new_device']:
        reasons.append('login is from a new device')
    if signals['behavior_score'] < 0.55:
        reasons.append('behavior differs from historical usage pattern')
    if signals['location_delta_km'] > 100:
        reasons.append('location movement is unusually large')
    if not reasons:
        reasons.append('device, SIM, behavior, and network signals are consistent with historical usage')
    return f"Decision {decision} because risk_score={risk_score:.2f}; " + '; '.join(reasons) + '.'


def create_sample() -> dict:
    signals = {
        'sim_changed_recently': bool(random.random() < 0.12),
        'imei_changed': bool(random.random() < 0.10),
        'is_new_device': bool(random.random() < 0.18),
        'behavior_score': round(float(np.random.uniform(0.25, 1.0)), 2),
        'location_delta_km': round(float(np.random.exponential(40)), 2),
        'app_type': random.choice(['food_delivery', 'grocery', 'ott', 'ecommerce', 'banking']),
    }
    risk = (
        0.35 * signals['sim_changed_recently']
        + 0.25 * signals['imei_changed']
        + 0.15 * signals['is_new_device']
        + 0.20 * (signals['behavior_score'] < 0.55)
        + 0.15 * (signals['location_delta_km'] > 100)
        + 0.10 * (signals['app_type'] == 'banking')
        + float(np.random.uniform(0, 0.15))
    )
    risk = min(risk, 1.0)
    level = 'high' if risk > 0.70 else 'medium' if risk > 0.30 else 'low'
    decision = DECISION_MAP[level]
    return {
        'messages': [
            {
                'role': 'system',
                'content': 'You are a telco security analyst. Explain adaptive authentication decisions using telecom, device, and behavior signals.'
            },
            {
                'role': 'user',
                'content': json.dumps({'signals': signals, 'risk_score': round(risk, 2)}, indent=2)
            },
            {
                'role': 'assistant',
                'content': json.dumps({'decision': decision, 'explanation': explain(signals, risk, decision)}, indent=2)
            },
        ]
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--num-samples', type=int, default=10000)
    parser.add_argument('--out', default='artifacts/llm_finetune/telco_security_sft.jsonl')
    args = parser.parse_args()
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open('w') as f:
        for _ in range(args.num_samples):
            f.write(json.dumps(create_sample()) + '\n')
    print(f'Wrote {args.num_samples:,} fine-tuning samples to {out}')


if __name__ == '__main__':
    main()
