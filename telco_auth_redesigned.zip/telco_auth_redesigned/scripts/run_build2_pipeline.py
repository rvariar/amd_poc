#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run(cmd: list[str]) -> None:
    env = os.environ.copy()
    env['PYTHONPATH'] = str(ROOT / 'src')
    print('$', ' '.join(cmd))
    subprocess.check_call(cmd, cwd=ROOT, env=env)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument('--num-users', type=int, default=5000)
    p.add_argument('--events-per-user', type=int, default=40)
    p.add_argument('--epochs', type=int, default=2)
    p.add_argument('--batch-size', type=int, default=512)
    p.add_argument('--seq-len', type=int, default=30)
    args = p.parse_args()

    py = sys.executable
    run([py, '-m', 'telco_auth.generators.sequence_generator', '--num-users', str(args.num_users), '--events-per-user', str(args.events_per_user), '--out', 'data/raw/auth_events.parquet'])
    run([py, '-m', 'telco_auth.models.train_transformer', '--events', 'data/raw/auth_events.parquet', '--seq-len', str(args.seq_len), '--epochs', str(args.epochs), '--batch-size', str(args.batch_size)])


if __name__ == '__main__':
    main()
