from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from telco_auth.schemas.event_schema import APP_TYPES, EVENT_COLUMNS
from telco_auth.utils.seed import set_seed


def sigmoid(x: float | np.ndarray) -> float | np.ndarray:
    return 1 / (1 + np.exp(-x))


def _choose_attack_starts(rng, events_per_user: int, horizon: int) -> set[int]:
    min_start = 10
    max_start = events_per_user - horizon - 2

    if max_start <= min_start:
        return set()

    candidates = np.arange(min_start, max_start)
    num_attacks = max(1, events_per_user // 25)
    num_attacks = min(num_attacks, len(candidates))

    return set(rng.choice(candidates, size=num_attacks, replace=False).tolist())


def _get_attack_phase(i: int, attack_starts: set[int]) -> str | None:
    for s in attack_starts:
        if i == s:
            return "sim_or_device_change"
        if i == s + 1:
            return "behavior_drop"
        if i == s + 2:
            return "location_jump"
        if i == s + 3:
            return "otp_retry"
        if i == s + 4:
            return "fraud"
    return None


def _generate_user_rows(
    user_start: int,
    user_end: int,
    events_per_user: int,
    horizon: int,
    seed: int,
) -> list[list]:
    rng = np.random.default_rng(seed + user_start)
    rows: list[list] = []

    num_users = user_end - user_start

    user_hidden_risk = rng.beta(2.0, 10.0, size=num_users)
    preferred_hour = rng.integers(6, 24, size=num_users)
    base_behavior = rng.uniform(0.76, 0.98, size=num_users)

    for local_u, u in enumerate(range(user_start, user_end)):
        user_id = f"U{u}"

        stable_sim_streak = int(rng.integers(20, 400))
        stable_device_streak = int(rng.integers(20, 600))

        failed_auth_streak = 0
        otp_retry_streak = 0

        recent_behavior_scores: list[float] = []
        recent_location_jumps: list[float] = []

        current_event_fraud_labels: list[int] = []
        user_rows: list[list] = []

        attack_starts = _choose_attack_starts(rng, events_per_user, horizon)

        for i in range(events_per_user):
            attack_phase = _get_attack_phase(i, attack_starts)

            app_type = int(
                rng.choice(
                    list(APP_TYPES.values()),
                    p=[0.25, 0.18, 0.18, 0.24, 0.15],
                )
            )

            app_risk_weight = [0.10, 0.12, 0.08, 0.18, 0.45][app_type]

            high_value_action = int(
                app_type in [APP_TYPES["banking"], APP_TYPES["ecommerce"]]
                and rng.random() < 0.18
            )

            hour = int(np.clip(rng.normal(preferred_hour[local_u], 2.5), 0, 23))
            hour_sin = float(np.sin(2 * np.pi * hour / 24))
            hour_cos = float(np.cos(2 * np.pi * hour / 24))

            hidden = user_hidden_risk[local_u]

            sim_changed = bool(rng.random() < (0.004 + 0.030 * hidden))
            imei_changed = bool(rng.random() < (0.006 + 0.040 * hidden))
            is_new_device = bool(rng.random() < (0.012 + 0.050 * hidden))
            roaming = bool(rng.random() < (0.015 + 0.035 * hidden))
            network_5g = int(rng.random() < 0.68)

            normal_jump = abs(rng.normal(4, 5))
            suspicious_jump = rng.random() < (0.008 + 0.045 * hidden)
            location_jump = float(
                normal_jump + (rng.uniform(120, 1200) if suspicious_jump else 0.0)
            )

            raw_behavior = base_behavior[local_u] - rng.beta(1.2, 14)
            raw_behavior -= 0.23 * is_new_device
            raw_behavior -= 0.18 * imei_changed
            raw_behavior -= 0.12 * sim_changed

            behavior_score = float(np.clip(raw_behavior, 0.05, 1.0))

            device_consistency = float(
                np.clip(
                    0.96
                    - 0.35 * is_new_device
                    - 0.25 * imei_changed
                    + rng.normal(0, 0.035),
                    0.03,
                    1.0,
                )
            )

            avg_recent_behavior = (
                float(np.mean(recent_behavior_scores[-5:]))
                if len(recent_behavior_scores) >= 5
                else behavior_score
            )

            behavior_drift = float(max(0.0, avg_recent_behavior - behavior_score))

            avg_recent_jump = (
                float(np.mean(recent_location_jumps[-5:]))
                if len(recent_location_jumps) >= 5
                else location_jump
            )

            velocity_spike = int(location_jump > max(90.0, avg_recent_jump * 4.0))

            sudden_sim_after_stable_history = int(
                sim_changed and stable_sim_streak >= 15
            )

            sudden_device_after_stable_history = int(
                (is_new_device or imei_changed) and stable_device_streak >= 15
            )

            failed_login_count_5 = int(min(failed_auth_streak, 5))
            otp_retry_count_5 = int(min(otp_retry_streak, 5))

            otp_retry_burst = int(otp_retry_streak >= 2)
            failed_auth_burst = int(failed_auth_streak >= 2)

            # -------------------------------------------------
            # Explicit attack campaign injection
            # -------------------------------------------------
            if attack_phase == "sim_or_device_change":
                sim_changed = True
                is_new_device = True
                imei_changed = True
                device_consistency = min(device_consistency, 0.35)
                sudden_sim_after_stable_history = int(stable_sim_streak >= 15)
                sudden_device_after_stable_history = int(stable_device_streak >= 15)

            elif attack_phase == "behavior_drop":
                behavior_score = min(behavior_score, 0.35)
                behavior_drift = max(behavior_drift, 0.45)

            elif attack_phase == "location_jump":
                location_jump = max(location_jump, 500.0)
                velocity_spike = 1

            elif attack_phase == "otp_retry":
                failed_auth = 1
                otp_retry = 1
                failed_auth_streak += 1
                otp_retry_streak += 1
            else:
                suspicious_score = (
                    1.4 * sim_changed
                    + 1.2 * imei_changed
                    + 1.0 * is_new_device
                    + 2.2 * sudden_sim_after_stable_history
                    + 2.0 * sudden_device_after_stable_history
                    + 1.8 * velocity_spike
                    + 1.6 * (behavior_drift > 0.20)
                    + 0.8 * roaming
                    + 0.8 * high_value_action
                    + 2.4 * hidden
                )

                failed_auth = int(sigmoid(-2.0 + 0.65 * suspicious_score) > rng.random())
                otp_retry = int(
                    sigmoid(-2.2 + 0.55 * suspicious_score + 0.5 * failed_auth)
                    > rng.random()
                )

            otp_used = int(
                sim_changed
                or is_new_device
                or high_value_action
                or app_type == APP_TYPES["banking"]
                or otp_retry
                or rng.random() < 0.06
            )

            risk_logit = (
                -5.4
                + 2.2 * sim_changed
                + 2.0 * imei_changed
                + 1.8 * is_new_device
                + 3.8 * sudden_sim_after_stable_history
                + 3.5 * sudden_device_after_stable_history
                + 3.4 * velocity_spike
                + 3.2 * (behavior_drift > 0.25)
                + 2.4 * otp_retry_burst
                + 2.2 * failed_auth_burst
                + 1.4 * failed_auth
                + 1.3 * otp_retry
                + 1.0 * roaming
                + 0.9 * high_value_action
                + 1.4 * app_risk_weight
                + 2.5 * hidden
                + rng.normal(0, 0.18)
            )

            current_event_fraud = int(sigmoid(risk_logit) > rng.random())

            if attack_phase == "fraud":
                current_event_fraud = 1
                high_value_action = 1
                failed_auth = 1
                otp_retry = 1

            current_event_fraud_labels.append(current_event_fraud)

            user_rows.append(
                [
                    user_id,
                    i,
                    i * 60 + int(rng.integers(0, 60)),
                    app_type,
                    device_consistency,
                    int(is_new_device),
                    int(sim_changed),
                    int(imei_changed),
                    behavior_score,
                    location_jump,
                    hour_sin,
                    hour_cos,
                    int(network_5g),
                    int(roaming),
                    int(otp_used),
                    behavior_drift,
                    int(velocity_spike),
                    int(sudden_sim_after_stable_history),
                    int(sudden_device_after_stable_history),
                    int(otp_retry_burst),
                    int(failed_auth_burst),
                    int(failed_auth),
                    int(otp_retry),
                    int(high_value_action),
                    int(failed_login_count_5),
                    int(otp_retry_count_5),
                    float(app_risk_weight),
                    int(current_event_fraud),
                    0,
                ]
            )

            stable_sim_streak = 0 if sim_changed else stable_sim_streak + 1
            stable_device_streak = (
                0 if (is_new_device or imei_changed) else stable_device_streak + 1
            )

            failed_auth_streak = failed_auth_streak + 1 if failed_auth else 0
            otp_retry_streak = otp_retry_streak + 1 if otp_retry else 0

            recent_behavior_scores.append(behavior_score)
            recent_location_jumps.append(location_jump)

        for i, row in enumerate(user_rows):
            future_slice = current_event_fraud_labels[i + 1 : i + 1 + horizon]
            row[-1] = int(max(future_slice) if future_slice else 0)
            rows.append(row)

    return rows


def generate_auth_events(
    num_users: int = 10000,
    events_per_user: int = 50,
    horizon: int = 5,
    seed: int = 42,
) -> pd.DataFrame:
    rows = _generate_user_rows(0, num_users, events_per_user, horizon, seed)
    return pd.DataFrame(rows, columns=EVENT_COLUMNS)


def write_events_chunked(
    num_users: int,
    events_per_user: int,
    horizon: int,
    seed: int,
    chunk_users: int,
    out: Path,
) -> None:
    out.parent.mkdir(parents=True, exist_ok=True)

    if out.exists():
        out.unlink()

    import pyarrow as pa
    import pyarrow.parquet as pq

    writer = None
    total = 0

    for start in range(0, num_users, chunk_users):
        end = min(start + chunk_users, num_users)

        rows = _generate_user_rows(start, end, events_per_user, horizon, seed)
        df = pd.DataFrame(rows, columns=EVENT_COLUMNS)
        table = pa.Table.from_pandas(df, preserve_index=False)

        if writer is None:
            writer = pq.ParquetWriter(out, table.schema)

        writer.write_table(table)

        total += len(df)

        print(
            f"chunk users {start:,}-{end:,}: "
            f"wrote {len(df):,} rows | total={total:,}"
        )

    if writer is not None:
        writer.close()


def main() -> None:
    parser = argparse.ArgumentParser()

    parser.add_argument("--num-users", type=int, default=10000)
    parser.add_argument("--events-per-user", type=int, default=50)
    parser.add_argument("--horizon", type=int, default=5)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument(
        "--chunk-users",
        type=int,
        default=0,
        help="Use chunked parquet writing for large datasets",
    )
    parser.add_argument("--out", default="data/raw/auth_events.parquet")

    args = parser.parse_args()

    set_seed(args.seed)

    out = Path(args.out)

    if args.chunk_users and args.chunk_users > 0:
        write_events_chunked(
            args.num_users,
            args.events_per_user,
            args.horizon,
            args.seed,
            args.chunk_users,
            out,
        )
        df = pd.read_parquet(
            out,
            columns=["current_event_fraud", "future_fraud_next_5"],
        )
    else:
        df = generate_auth_events(
            args.num_users,
            args.events_per_user,
            args.horizon,
            args.seed,
        )

        out.parent.mkdir(parents=True, exist_ok=True)

        if out.suffix == ".parquet":
            df.to_parquet(out, index=False)
        else:
            df.to_csv(out, index=False)

    print(f"Wrote {len(df):,} events to {out}")

    print("current_event_fraud")
    print(df["current_event_fraud"].value_counts(normalize=True).rename("rate"))

    print("future_fraud_next_5")
    print(df["future_fraud_next_5"].value_counts(normalize=True).rename("rate"))


if __name__ == "__main__":
    main()
