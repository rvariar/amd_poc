from __future__ import annotations

import json
from openai import OpenAI


class QwenVLLMClient:
    def __init__(self, base_url: str = "http://localhost:8000/v1", api_key: str = "abc-123", model: str = "Qwen3-30B-A3B"):
        self.client = OpenAI(base_url=base_url, api_key=api_key)
        self.model = model

    def explain_decision(self, payload: dict) -> str:
        prompt = f"""
You are a Telco Security LLM. Explain this adaptive authentication decision.

Do not include hidden reasoning.
Do not include <think> tags.
Return JSON only with keys:
decision, explanation, audit_notes, recommended_action.
If velocity_spike is 0, do not describe location_jump as a significant anomaly.
If guardrail_reasons is empty, say no hard guardrail was triggered.
Base explanation primarily on risk_score, decision, and explicit triggered signals.
If velocity_spike is 0, location_jump must be treated as normal movement and must not be used as a risk reason.
Payload:
{json.dumps(payload, indent=2, default=str)}
""" 
        res = self.client.chat.completions.create(
             model=self.model,
             messages=[
                   {"role": "system", "content": "You are a telecom security expert. Return JSON only. Never cite inactive signals as risk reasons. If a signal is 0, it is not triggered."},
                   {"role": "user", "content": prompt},
             ],
             temperature=0.1,
             max_tokens=400,
             extra_body={"chat_template_kwargs": {"enable_thinking": False}},
        )        
        return res.choices[0].message.content
