#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from telco_auth.serving.risk_pipeline import TransformerRiskEngine


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--events",
        default="data/raw/auth_events.parquet"
    )
    parser.add_argument(
        "--checkpoint",
        default="artifacts/checkpoints/transformer_risk_model.pt"
    )
    parser.add_argument(
        "--sample-users",
        type=int,
        default=1000
    )
    parser.add_argument(
        "--out",
        default="reports/auth_decision_distribution.json"
    )

    args = parser.parse_args()

    print("Loading events...")
    df = pd.read_parquet(args.events)

    print(f"Loaded {len(df):,} events")

    users = (
        df["user_id"]
        .drop_duplicates()
        .sample(
            min(args.sample_users, df["user_id"].nunique()),
            random_state=42
        )
        .tolist()
    )

    print(f"Evaluating {len(users):,} users")

    engine = TransformerRiskEngine(args.checkpoint)

    counts = {
        "NO_OTP": 0,
        "STEP_UP_AUTH": 0,
        "OTP_REQUIRED": 0
    }

    risk_scores = []

    for idx, user_id in enumerate(users, start=1):

        seq = (
            df[df["user_id"] == user_id]
            .sort_values("event_index")
        )

        result = engine.decide(seq)

        counts[result["decision"]] += 1
        risk_scores.append(result["risk_score"])

        if idx % 100 == 0:
            print(f"Processed {idx}/{len(users)} users")

    total = sum(counts.values())

    summary = {
        "sample_users": total,
        "decision_counts": counts,
        "decision_percentages": {
            k: round(v * 100.0 / total, 2)
            for k, v in counts.items()
        },
        "avg_risk_score": round(sum(risk_scores) / len(risk_scores), 4),
        "min_risk_score": round(min(risk_scores), 4),
        "max_risk_score": round(max(risk_scores), 4),
    }

    Path(args.out).parent.mkdir(
        parents=True,
        exist_ok=True
    )

    with open(args.out, "w") as f:
        json.dump(summary, f, indent=2)

    print("\n========== RESULTS ==========")
    print(json.dumps(summary, indent=2))
    print(f"\nSaved to {args.out}")


if __name__ == "__main__":
    main()
