#!/usr/bin/env python3
from __future__ import annotations

import argparse
import pandas as pd

from telco_auth.serving.risk_pipeline import TransformerRiskEngine
from telco_auth.llm.qwen_client import QwenVLLMClient


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--events", default="data/raw/auth_events.parquet")
    parser.add_argument("--checkpoint", default="artifacts/checkpoints/transformer_risk_model.pt")
    parser.add_argument("--base-url", default="http://localhost:8000/v1")
    parser.add_argument("--api-key", default="abc-123")
    parser.add_argument("--model", default="Qwen3-30B-A3B")
    parser.add_argument("--user-id", default=None)
    parser.add_argument("--skip-llm", action="store_true")
    args = parser.parse_args()

    print("Loading events...", flush=True)
    df = pd.read_parquet(args.events) if args.events.endswith(".parquet") else pd.read_csv(args.events)
    print(f"Loaded events: {len(df):,}", flush=True)

    #user_id = args.user_id or df["user_id"].iloc[0]
    user_id = args.user_id or df["user_id"].sample(1).iloc[0]
    print(f"Selected user_id={user_id}", flush=True)

    seq = df[df["user_id"] == user_id].sort_values("event_index")
    print(f"User sequence length={len(seq)}", flush=True)

    print("Loading Transformer risk engine...", flush=True)
    engine = TransformerRiskEngine(args.checkpoint)

    print("Running Transformer + guardrails decision...", flush=True)
    decision = engine.decide(seq)

    print("\nTransformer + Guardrails Decision:", flush=True)
    print(decision, flush=True)

    if args.skip_llm:
        print("\nLLM skipped by --skip-llm", flush=True)
        return

    print("\nCalling vLLM for explanation...", flush=True)

    try:
        qwen = QwenVLLMClient(args.base_url, args.api_key, args.model)
        explanation = qwen.explain_decision(decision)
        print("\nLLM Explanation:", flush=True)
        print(explanation, flush=True)
    except Exception as e:
        print("\nLLM explanation skipped. vLLM may not be running.", flush=True)
        print(e, flush=True)


if __name__ == "__main__":
    main()
