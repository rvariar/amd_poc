# Telco Auth AI: ROCm Transformer + Telco Security LLM

This project implements the redesigned hackathon flow:

## Build 2

```text
50M login events
      ↓
User sequences
      ↓
Transformer Encoder on AMD ROCm GPU
      ↓
Predict fraud in next 5 logins
```

The important correction from earlier experiments is that the Transformer now predicts a **future-window label** (`future_fraud_next_5`), not the current event label. This gives the model a sequence-specific learning problem.

## Build 3

```text
Qwen3-30B LoRA fine-tuning dataset
signals + risk_score + decision + explanation
```

The code generates JSONL instruction samples suitable for LoRA/SFT.

## Build 4

```text
vLLM
+
Transformer Risk Engine
+
Rule Guardrails
+
LoRA Qwen explanation/audit layer
```

The serving pipeline combines the trained Transformer risk score with security guardrails and an OpenAI-compatible vLLM endpoint.

---

## Quick start

```bash
python3 -m venv myenv
source myenv/bin/activate
pip install -U pip
pip install -r requirements.txt
```

For AMD ROCm PyTorch, if needed:

```bash
pip uninstall -y torch torchvision torchaudio
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/rocm6.1
```

Verify GPU:

```bash
python -c "import torch; print(torch.cuda.is_available()); print(torch.version.hip); print(torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'no gpu')"
```

---

## Build 2 small GPU test

```bash
PYTHONPATH=src python scripts/run_build2_pipeline.py \
  --num-users 5000 \
  --events-per-user 60 \
  --epochs 5
```

## Bigger ROCm run

```bash
PYTHONPATH=src python scripts/run_build2_pipeline.py \
  --num-users 50000 \
  --events-per-user 100 \
  --epochs 10 \
  --batch-size 1024
```

For 50M events, use chunked generation:

```bash
PYTHONPATH=src python -m telco_auth.generators.sequence_generator \
  --num-users 1000000 \
  --events-per-user 50 \
  --chunk-users 50000 \
  --out data/raw/auth_events.parquet
```

Then train:

```bash
PYTHONPATH=src python -m telco_auth.models.train_transformer \
  --events data/raw/auth_events.parquet \
  --seq-len 30 \
  --horizon 5 \
  --epochs 10 \
  --batch-size 1024
```

---

## Build 3 LoRA data

```bash
PYTHONPATH=src python scripts/create_build3_finetune_data.py \
  --events data/raw/auth_events.parquet \
  --model-report reports/build2_metrics.json \
  --num-samples 20000 \
  --out artifacts/llm_finetune/telco_security_sft.jsonl
```

Optional LoRA script skeleton:

```bash
PYTHONPATH=src python scripts/train_qwen_lora_skeleton.py \
  --model Qwen/Qwen3-30B-A3B \
  --train-jsonl artifacts/llm_finetune/telco_security_sft.jsonl
```

---

## Build 4 vLLM serving

Start vLLM:

```bash
bash scripts/serve_vllm_qwen.sh
```

Run integrated demo:

```bash
PYTHONPATH=src python scripts/run_build4_demo.py \
  --events data/raw/auth_events.parquet \
  --checkpoint artifacts/checkpoints/transformer_risk_model.pt \
  --base-url http://localhost:8000/v1 \
  --api-key abc-123
```
