#!/usr/bin/env bash
set -euo pipefail

export VLLM_USE_TRITON_FLASH_ATTN=0
MODEL_NAME=${MODEL_NAME:-Qwen/Qwen3-30B-A3B}
SERVED_MODEL_NAME=${SERVED_MODEL_NAME:-Qwen3-30B-A3B}
API_KEY=${API_KEY:-abc-123}
PORT=${PORT:-8000}

vllm serve "$MODEL_NAME" \
  --served-model-name "$SERVED_MODEL_NAME" \
  --api-key "$API_KEY" \
  --port "$PORT" \
  --enable-auto-tool-choice \
  --tool-call-parser hermes \
  --trust-remote-code
