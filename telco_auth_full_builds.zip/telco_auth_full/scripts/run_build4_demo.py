#!/usr/bin/env python3
from __future__ import annotations

import argparse
import pandas as pd

from telco_auth.serving.risk_pipeline import TransformerRiskEngine
from telco_auth.llm.qwen_client import QwenVLLMClient


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--events", default="data/raw/auth_events.parquet")
    parser.add_argument("--checkpoint", default="artifacts/checkpoints/transformer_risk_model.pt")
    parser.add_argument("--base-url", default="http://localhost:8000/v1")
    parser.add_argument("--api-key", default="abc-123")
    parser.add_argument("--model", default="Qwen3-30B-A3B")
    parser.add_argument("--user-id", default=None)
    args = parser.parse_args()

    df = pd.read_parquet(args.events) if args.events.endswith(".parquet") else pd.read_csv(args.events)
    user_id = args.user_id or df["user_id"].iloc[0]
    seq = df[df["user_id"] == user_id].sort_values("event_index")
    engine = TransformerRiskEngine(args.checkpoint)
    decision = engine.decide(seq)
    print("Transformer + Guardrails Decision:")
    print(decision)

    try:
        qwen = QwenVLLMClient(args.base_url, args.api_key, args.model)
        print("\nLLM Explanation:")
        print(qwen.explain_decision(decision))
    except Exception as e:
        print("\nLLM explanation skipped. vLLM may not be running.")
        print(e)


if __name__ == "__main__":
    main()
