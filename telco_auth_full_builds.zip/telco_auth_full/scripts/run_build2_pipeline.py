#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run(cmd):
    env = os.environ.copy()
    env["PYTHONPATH"] = str(ROOT / "src")
    print("$", " ".join(str(x) for x in cmd), flush=True)
    subprocess.check_call([str(x) for x in cmd], cwd=ROOT, env=env)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--num-users", type=int, default=5000)
    parser.add_argument("--events-per-user", type=int, default=60)
    parser.add_argument("--horizon", type=int, default=5)
    parser.add_argument("--seq-len", type=int, default=30)
    parser.add_argument("--epochs", type=int, default=8)
    parser.add_argument("--batch-size", type=int, default=512)
    parser.add_argument("--chunk-users", type=int, default=0)
    args = parser.parse_args()

    py = sys.executable
    gen_cmd = [py, "-m", "telco_auth.generators.sequence_generator", "--num-users", args.num_users, "--events-per-user", args.events_per_user, "--horizon", args.horizon, "--out", "data/raw/auth_events.parquet"]
    if args.chunk_users:
        gen_cmd.extend(["--chunk-users", args.chunk_users])
    run(gen_cmd)
    run([py, "-m", "telco_auth.models.train_transformer", "--events", "data/raw/auth_events.parquet", "--seq-len", args.seq_len, "--horizon", args.horizon, "--epochs", args.epochs, "--batch-size", args.batch_size])


if __name__ == "__main__":
    main()
