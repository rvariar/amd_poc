#!/usr/bin/env python3
from telco_auth.build3.train_lora_skeleton import main

if __name__ == "__main__":
    main()
