#!/usr/bin/env python3
from telco_auth.build3.finetune_data import main

if __name__ == "__main__":
    main()
