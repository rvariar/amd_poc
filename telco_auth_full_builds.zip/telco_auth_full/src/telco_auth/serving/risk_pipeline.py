from __future__ import annotations

from pathlib import Path
import pandas as pd
import torch

from telco_auth.models.sequence_dataset import AuthSequenceDataset
from telco_auth.models.transformer_risk_model import TransformerRiskModel
from telco_auth.schemas.event_schema import FEATURE_COLUMNS
from telco_auth.rules.guardrails import apply_guardrails
from telco_auth.utils.device import get_device


class TransformerRiskEngine:
    def __init__(self, checkpoint: str):
        self.device = get_device()
        ckpt = torch.load(checkpoint, map_location=self.device)
        self.seq_len = ckpt["seq_len"]
        self.threshold = ckpt.get("selected_threshold", 0.5)
        self.feature_columns = ckpt.get("feature_columns", FEATURE_COLUMNS)
        self.model = TransformerRiskModel(feature_dim=len(self.feature_columns)).to(self.device)
        self.model.load_state_dict(ckpt["model_state_dict"])
        self.model.eval()

    @torch.no_grad()
    def score_sequence(self, seq_df: pd.DataFrame) -> float:
        x = seq_df[self.feature_columns].astype("float32").to_numpy()
        if len(x) < self.seq_len:
            pad = x[:1].repeat(self.seq_len - len(x), axis=0)
            x = pd.concat([pd.DataFrame(pad), pd.DataFrame(x)], ignore_index=True).to_numpy()
        x = x[-self.seq_len:]
        xt = torch.tensor(x, dtype=torch.float32).unsqueeze(0).to(self.device)
        prob = torch.sigmoid(self.model(xt)).item()
        return float(prob)

    def decide(self, seq_df: pd.DataFrame) -> dict:
        model_risk = self.score_sequence(seq_df)
        latest = seq_df.iloc[-1].to_dict()
        guarded = apply_guardrails(latest, model_risk)
        return {"model_risk_score": round(model_risk, 4), **guarded, "signals": latest}
