from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from telco_auth.rules.guardrails import apply_guardrails


def explain(signals: dict, risk_score: float, decision: str, reasons: list[str]) -> str:
    if reasons:
        return f"{decision} because " + "; ".join(reasons) + f". Model risk={risk_score:.2f}."
    if decision == "OTP_REQUIRED":
        return f"OTP required because the fraud risk score is high ({risk_score:.2f}) even without hard guardrail triggers."
    if decision == "STEP_UP_AUTH":
        return f"Step-up authentication because risk is moderate ({risk_score:.2f}); use biometric or silent device check before OTP."
    return f"No OTP required because telecom, device, and behavior signals are low risk ({risk_score:.2f})."


def build_sample(row: pd.Series) -> dict:
    signals = row.to_dict()
    # synthetic model score derived from visible risk markers for SFT generation
    model_risk = min(0.99, max(0.01, 0.08
        + 0.28 * signals.get("sim_changed", 0)
        + 0.25 * signals.get("imei_changed", 0)
        + 0.25 * signals.get("is_new_device", 0)
        + 0.32 * signals.get("sudden_sim_after_stable_history", 0)
        + 0.30 * signals.get("sudden_device_after_stable_history", 0)
        + 0.28 * signals.get("velocity_spike", 0)
        + 0.18 * signals.get("failed_auth_burst", 0)
        + 0.15 * signals.get("otp_retry_burst", 0)
        + np.random.normal(0, 0.03)
    ))
    guarded = apply_guardrails(signals, model_risk)
    decision = guarded["decision"]
    risk_score = guarded["risk_score"]
    instruction = "Given telecom authentication signals, decide whether to skip OTP, require step-up authentication, or require OTP. Explain for audit."
    input_obj = {"signals": {k: signals[k] for k in signals if k not in ["user_id"]}, "risk_score": risk_score}
    output_obj = {
        "decision": decision,
        "risk_score": risk_score,
        "explanation": explain(signals, risk_score, decision, guarded["guardrail_reasons"]),
        "audit_notes": guarded["guardrail_reasons"],
    }
    return {"instruction": instruction, "input": input_obj, "output": output_obj}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--events", default="data/raw/auth_events.parquet")
    parser.add_argument("--num-samples", type=int, default=10000)
    parser.add_argument("--out", default="artifacts/llm_finetune/telco_security_sft.jsonl")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    rng = np.random.default_rng(args.seed)
    df = pd.read_parquet(args.events) if args.events.endswith(".parquet") else pd.read_csv(args.events)
    if len(df) > args.num_samples:
        df = df.sample(args.num_samples, random_state=args.seed)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w") as f:
        for _, row in df.iterrows():
            f.write(json.dumps(build_sample(row), default=str) + "\n")
    print(f"Wrote {len(df):,} SFT samples to {out}")


if __name__ == "__main__":
    main()
