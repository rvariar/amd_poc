from __future__ import annotations

"""LoRA training skeleton for Qwen3-30B.

This file is intentionally a skeleton because exact ROCm memory behavior depends on
available GPU VRAM. For a hackathon, use the generated JSONL as proof of Build 3 data
and run LoRA when environment supports the selected Qwen checkpoint.
"""

import argparse


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="Qwen/Qwen3-30B-A3B")
    parser.add_argument("--train-jsonl", default="artifacts/llm_finetune/telco_security_sft.jsonl")
    parser.add_argument("--out-dir", default="artifacts/lora_adapters/qwen_telco_security")
    args = parser.parse_args()
    print("LoRA training skeleton")
    print(f"Base model: {args.model}")
    print(f"Train data: {args.train_jsonl}")
    print(f"Output adapter: {args.out_dir}")
    print("Recommended stack: transformers + peft + accelerate, bf16/fp16 if ROCm device supports it.")


if __name__ == "__main__":
    main()
