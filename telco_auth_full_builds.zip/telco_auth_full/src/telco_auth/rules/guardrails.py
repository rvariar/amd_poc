from __future__ import annotations


def apply_guardrails(signals: dict, model_risk: float) -> dict:
    """Security-first rule guardrails.

    The Transformer provides adaptive risk, while guardrails enforce known high-risk
    telecom/security conditions.
    """
    risk = float(model_risk)
    reasons = []

    if signals.get("sudden_sim_after_stable_history", 0):
        risk = max(risk, 0.92)
        reasons.append("SIM changed after long stable SIM history")
    if signals.get("sudden_device_after_stable_history", 0):
        risk = max(risk, 0.88)
        reasons.append("Device/IMEI changed after long stable device history")
    if signals.get("velocity_spike", 0):
        risk = max(risk, 0.82)
        reasons.append("Impossible or unusual location velocity detected")
    if signals.get("high_value_action", 0) and risk > 0.45:
        risk = max(risk, 0.75)
        reasons.append("High-value action with non-low model risk")

    if risk >= 0.75:
        decision = "OTP_REQUIRED"
    elif risk >= 0.35:
        decision = "STEP_UP_AUTH"
    else:
        decision = "NO_OTP"

    return {"risk_score": round(risk, 4), "decision": decision, "guardrail_reasons": reasons}
