from __future__ import annotations

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset

from telco_auth.schemas.event_schema import FEATURE_COLUMNS, FUTURE_LABEL_COLUMN


class AuthSequenceDataset(Dataset):
    """Sequence dataset grouped by user.

    Each sample contains the previous seq_len events and the label on the last row:
    future_fraud_next_5 = whether fraud occurs in next 5 logins after that row.
    """

    def __init__(self, events: pd.DataFrame, seq_len: int = 30):
        self.seq_len = seq_len
        self.samples: list[tuple[np.ndarray, float]] = []

        required = set(FEATURE_COLUMNS + [FUTURE_LABEL_COLUMN, "user_id", "event_index"])
        missing = required - set(events.columns)
        if missing:
            raise ValueError(f"Missing columns: {sorted(missing)}")

        df = events.sort_values(["user_id", "event_index"]).copy()
        for _, g in df.groupby("user_id", sort=False):
            x = g[FEATURE_COLUMNS].astype("float32").to_numpy()
            y = g[FUTURE_LABEL_COLUMN].astype("float32").to_numpy()
            if len(g) < seq_len:
                continue
            for end in range(seq_len - 1, len(g)):
                self.samples.append((x[end - seq_len + 1 : end + 1], float(y[end])))

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int):
        x, y = self.samples[idx]
        return torch.tensor(x, dtype=torch.float32), torch.tensor(y, dtype=torch.float32)
