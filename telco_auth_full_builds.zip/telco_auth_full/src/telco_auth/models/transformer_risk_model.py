from __future__ import annotations

import torch
from torch import nn


class TransformerRiskModel(nn.Module):
    def __init__(self, feature_dim: int, d_model: int = 128, nhead: int = 8, num_layers: int = 4, dropout: float = 0.15):
        super().__init__()
        self.input_proj = nn.Linear(feature_dim, d_model)
        self.pos_embedding = nn.Parameter(torch.randn(1, 512, d_model) * 0.02)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=d_model * 4,
            dropout=dropout,
            batch_first=True,
            activation="gelu",
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.head = nn.Sequential(
            nn.LayerNorm(d_model),
            nn.Linear(d_model, d_model // 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_model // 2, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, T, F]
        h = self.input_proj(x)
        h = h + self.pos_embedding[:, : h.size(1), :]
        h = self.encoder(h)
        last = h[:, -1, :]
        return self.head(last).squeeze(-1)
