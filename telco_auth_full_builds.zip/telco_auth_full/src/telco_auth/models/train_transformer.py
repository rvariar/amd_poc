from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader, random_split
from sklearn.metrics import classification_report, confusion_matrix, f1_score, precision_score, recall_score, roc_auc_score

from telco_auth.models.sequence_dataset import AuthSequenceDataset
from telco_auth.models.transformer_risk_model import TransformerRiskModel
from telco_auth.schemas.event_schema import FEATURE_COLUMNS
from telco_auth.utils.device import get_device, device_report
from telco_auth.utils.seed import set_seed


def load_events(path: str) -> pd.DataFrame:
    p = Path(path)
    return pd.read_parquet(p) if p.suffix == ".parquet" else pd.read_csv(p)


def collect_probs(model, loader, device):
    model.eval()
    probs, labels = [], []
    with torch.no_grad():
        for x, y in loader:
            x = x.to(device, non_blocking=True)
            logits = model(x)
            p = torch.sigmoid(logits).detach().cpu().numpy()
            probs.extend(p.tolist())
            labels.extend(y.numpy().tolist())
    return np.array(probs), np.array(labels).astype(int)


def threshold_sweep(labels, probs):
    rows = []
    for t in np.arange(0.05, 0.95, 0.05):
        preds = (probs >= t).astype(int)
        rows.append({
            "threshold": round(float(t), 2),
            "recall": float(recall_score(labels, preds, zero_division=0)),
            "precision": float(precision_score(labels, preds, zero_division=0)),
            "f1": float(f1_score(labels, preds, zero_division=0)),
            "positive_prediction_rate": float(preds.mean()),
        })
    best_f1 = max(rows, key=lambda r: r["f1"])
    candidates = [r for r in rows if r["recall"] >= 0.90 and r["precision"] >= 0.25]
    recall_policy = max(candidates, key=lambda r: r["f1"]) if candidates else best_f1
    return rows, best_f1, recall_policy


def evaluate_from_probs(labels, probs, threshold: float) -> dict:
    preds = (probs >= threshold).astype(int)
    cm = confusion_matrix(labels, preds)
    return {
        "threshold": float(threshold),
        "roc_auc": float(roc_auc_score(labels, probs)) if len(np.unique(labels)) > 1 else 0.0,
        "recall": float(recall_score(labels, preds, zero_division=0)),
        "precision": float(precision_score(labels, preds, zero_division=0)),
        "f1": float(f1_score(labels, preds, zero_division=0)),
        "positive_prediction_rate": float(preds.mean()),
        "prob_min": float(probs.min()),
        "prob_max": float(probs.max()),
        "prob_mean": float(probs.mean()),
        "confusion_matrix": cm.tolist(),
        "classification_report": classification_report(labels, preds, zero_division=0),
    }


def labels_from_subset(subset):
    labels = []
    for idx in subset.indices:
        _, y = subset.dataset[idx]
        labels.append(float(y.item()))
    return np.array(labels)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--events", default="data/raw/auth_events.parquet")
    parser.add_argument("--seq-len", type=int, default=30)
    parser.add_argument("--horizon", type=int, default=5)
    parser.add_argument("--epochs", type=int, default=8)
    parser.add_argument("--batch-size", type=int, default=512)
    parser.add_argument("--lr", type=float, default=2e-4)
    parser.add_argument("--out-dir", default="artifacts/checkpoints")
    parser.add_argument("--report-dir", default="reports")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    set_seed(args.seed)
    device = get_device()
    print(device_report())

    df = load_events(args.events)
    dataset = AuthSequenceDataset(df, seq_len=args.seq_len)
    print(f"Sequence samples: {len(dataset):,} | feature_dim={len(FEATURE_COLUMNS)}")

    train_size = int(0.8 * len(dataset))
    val_size = len(dataset) - train_size
    train_ds, val_ds = random_split(dataset, [train_size, val_size], generator=torch.Generator().manual_seed(args.seed))

    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, num_workers=2, pin_memory=torch.cuda.is_available())
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False, num_workers=2, pin_memory=torch.cuda.is_available())

    model = TransformerRiskModel(feature_dim=len(FEATURE_COLUMNS)).to(device)

    train_labels = labels_from_subset(train_ds)
    pos = max(train_labels.sum(), 1.0)
    neg = max(len(train_labels) - pos, 1.0)
    pos_weight_value = min(neg / pos, 20.0)
    pos_weight = torch.tensor([pos_weight_value], dtype=torch.float32, device=device)
    print(f"train future_fraud_rate={train_labels.mean():.4f} pos={int(pos)} neg={int(neg)} pos_weight={pos_weight_value:.2f}")

    loss_fn = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=0.01)
    scaler = torch.cuda.amp.GradScaler(enabled=torch.cuda.is_available())

    history = []
    final_output = None
    best_model_auc = -1.0
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    report_dir = Path(args.report_dir)
    report_dir.mkdir(parents=True, exist_ok=True)

    for epoch in range(1, args.epochs + 1):
        model.train()
        total_loss = 0.0
        for x, y in train_loader:
            x = x.to(device, non_blocking=True)
            y = y.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with torch.cuda.amp.autocast(enabled=torch.cuda.is_available()):
                logits = model(x)
                loss = loss_fn(logits, y)
            scaler.scale(loss).backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            scaler.step(optimizer)
            scaler.update()
            total_loss += loss.item() * x.size(0)

        train_loss = total_loss / len(train_ds)
        probs, labels = collect_probs(model, val_loader, device)
        sweep, best_f1, recall_policy = threshold_sweep(labels, probs)
        metrics = evaluate_from_probs(labels, probs, recall_policy["threshold"])
        print(
            f"epoch={epoch} loss={train_loss:.4f} auc={metrics['roc_auc']:.4f} "
            f"threshold={metrics['threshold']:.2f} recall={metrics['recall']:.4f} "
            f"precision={metrics['precision']:.4f} f1={metrics['f1']:.4f} "
            f"prob_mean={metrics['prob_mean']:.4f} pred_rate={metrics['positive_prediction_rate']:.4f}"
        )
        row = {"epoch": epoch, "loss": train_loss, "best_f1": best_f1, "recall_policy": recall_policy, **{k: v for k, v in metrics.items() if k != "classification_report"}}
        history.append(row)
        final_output = {"history": history, "threshold_sweep": sweep, "best_f1_threshold": best_f1, "recall_first_threshold": recall_policy, "final_metrics": metrics, "final_report": metrics["classification_report"]}
        if metrics["roc_auc"] > best_model_auc:
            best_model_auc = metrics["roc_auc"]
            torch.save({"model_state_dict": model.state_dict(), "feature_columns": FEATURE_COLUMNS, "seq_len": args.seq_len, "selected_threshold": recall_policy["threshold"]}, out_dir / "transformer_risk_model.pt")

    with open(out_dir / "metrics.json", "w") as f:
        json.dump(final_output, f, indent=2)
    with open(report_dir / "build2_metrics.json", "w") as f:
        json.dump(final_output, f, indent=2)
    print(final_output["final_report"])
    print(f"Saved model and metrics to {out_dir}; report to {report_dir / 'build2_metrics.json'}")


if __name__ == "__main__":
    main()
