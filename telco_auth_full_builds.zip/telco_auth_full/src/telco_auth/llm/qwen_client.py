from __future__ import annotations

import json
from openai import OpenAI


class QwenVLLMClient:
    def __init__(self, base_url: str = "http://localhost:8000/v1", api_key: str = "abc-123", model: str = "Qwen3-30B-A3B"):
        self.client = OpenAI(base_url=base_url, api_key=api_key)
        self.model = model

    def explain_decision(self, payload: dict) -> str:
        prompt = f"""
You are a Telco Security LLM. Explain this adaptive authentication decision.
Return JSON with keys: decision, explanation, audit_notes, recommended_action.

Payload:
{json.dumps(payload, indent=2, default=str)}
"""
        res = self.client.chat.completions.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.1,
        )
        return res.choices[0].message.content
