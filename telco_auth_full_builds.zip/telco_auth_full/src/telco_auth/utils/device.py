from __future__ import annotations

import torch


def get_device() -> torch.device:
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def device_report() -> str:
    if torch.cuda.is_available():
        return f"GPU available: {torch.cuda.get_device_name(0)} | device_count={torch.cuda.device_count()} | hip={torch.version.hip}"
    return "CPU only: torch.cuda.is_available() is False"
